using System.Collections.Generic;
using Microsoft.AspNetCore.Components;

namespace FrontTcc_Luiz.Models
{
    public class ProdutosViewModel
    {
        public string Nome { get; set; } = string.Empty;
        public string Categoria { get; set; } = string.Empty;
        public string Descricao { get; set; } = string.Empty;
        public decimal Preco { get; set; }
        public int Estoque { get; set; }

        public List<ProdutosViewModel> Produtos { get; private set; } = new();

        private NavigationManager? _navigation;
        private ProdutoService? _produtoService;

        public ProdutosViewModel() { }

        public ProdutosViewModel(NavigationManager navigation, ProdutoService produtoService)
        {
            _navigation = navigation;
            _produtoService = produtoService;
        }

        public void CarregarProdutos()
        {
            if (_produtoService == null)
            {
                Produtos = new();
                return;
            }

            Produtos = _produtoService.ObterProdutos();
        }
    }
}
