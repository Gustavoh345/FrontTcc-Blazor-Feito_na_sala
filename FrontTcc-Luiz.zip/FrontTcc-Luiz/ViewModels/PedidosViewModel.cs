using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FrontTcc_Luiz.ViewModels
{
    public class PedidosViewModel
    {

    }
}